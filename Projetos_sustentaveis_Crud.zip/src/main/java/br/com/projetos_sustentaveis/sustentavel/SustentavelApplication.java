package br.com.projetos_sustentaveis.sustentavel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SustentavelApplication {

    public static void main(String[] args) {
        SpringApplication.run(SustentavelApplication.class, args);
    }

}
