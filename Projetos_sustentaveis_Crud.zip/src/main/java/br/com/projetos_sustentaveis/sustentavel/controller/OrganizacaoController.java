package br.com.projetos_sustentaveis.sustentavel.controller;

import br.com.projetos_sustentaveis.sustentavel.dto.OrganizacaoDTO;
import br.com.projetos_sustentaveis.sustentavel.entity.Organizacao;
import br.com.projetos_sustentaveis.sustentavel.service.OrganizacaoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/organizations")
public class OrganizacaoController {

    private final OrganizacaoService service;

    public OrganizacaoController(OrganizacaoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<?> criar(@RequestBody OrganizacaoDTO dto) {
        Organizacao org = service.salvar(dto);
        return ResponseEntity.ok(org);
    }

    @GetMapping
    public ResponseEntity<List<Organizacao>> listarTodas() {
        List<Organizacao> organizacoes = service.listarTodas();
        return ResponseEntity.ok(organizacoes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        Optional<Organizacao> org = service.buscarPorId(id);

        if (org.isPresent()) {
            return ResponseEntity.ok(org.get());
        } else {
            return ResponseEntity.status(404).body("Organização não encontrada");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody OrganizacaoDTO dto) {
        Optional<Organizacao> atualizado = service.atualizar(id, dto);

        if (atualizado.isPresent()) {
            return ResponseEntity.ok(atualizado.get());
        } else {
            return ResponseEntity.badRequest().body("Organização não encontrada");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        boolean deleted = service.deletar(id);

        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(404).body("Organização não encontrada");
        }
    }
}