package br.com.projetos_sustentaveis.sustentavel.service;

import br.com.projetos_sustentaveis.sustentavel.dto.OrganizacaoDTO;
import br.com.projetos_sustentaveis.sustentavel.entity.Organizacao;
import br.com.projetos_sustentaveis.sustentavel.repository.OrganizacaoRepository;
import com.fasterxml.jackson.core.PrettyPrinter;
import jakarta.persistence.Id;
import org.hibernate.dialect.unique.CreateTableUniqueDelegate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrganizacaoService {

    private final OrganizacaoRepository repository;

    public OrganizacaoService(OrganizacaoRepository repository) {
        this.repository = repository;
    }

    public Organizacao salvar(OrganizacaoDTO dto) {
        Organizacao org = new Organizacao();
        org.setName(dto.nome());
        org.setContato(dto.contato());
        return repository.save(org);
    }

    public List<Organizacao> listarTodas() {
        return repository.findAll();
    }

    public Optional<Organizacao> buscarPorId(Long id) {
        return repository.findById(id);
    }

    public Optional<Organizacao> atualizar(Long id, OrganizacaoDTO dto) {
        return repository.findById(id).map(org -> {
            org.setName(dto.nome());
            org.setContato(dto.contato());
            return repository.save(org);
        });
    }

    public boolean deletar(Long id) {
        return repository.findById(id).map(org -> {
            repository.delete(org);
            return true;
        }).orElse(false);
    }
}
