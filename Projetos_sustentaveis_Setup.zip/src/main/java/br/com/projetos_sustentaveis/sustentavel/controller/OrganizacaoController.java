package br.com.projetos_sustentaveis.sustentavel.controller;

import br.com.projetos_sustentaveis.sustentavel.entity.Organizacao;
import br.com.projetos_sustentaveis.sustentavel.service.OrganizacaoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/organizações")
public class OrganizacaoController {
    private final OrganizacaoService service;

    public OrganizacaoController(OrganizacaoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Organizacao> listar() {
        return service.listarTodas();
    }

    @PostMapping
    public ResponseEntity<Organizacao> criar(@RequestBody Organizacao organizacao) {
        return ResponseEntity.ok(service.salvar(organizacao));
    }
}
