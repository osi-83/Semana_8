package br.com.projetos_sustentaveis.sustentavel.controller;

import br.com.projetos_sustentaveis.sustentavel.entity.Projeto;
import br.com.projetos_sustentaveis.sustentavel.service.ProjetoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/projetos")
public class ProjetoController {

    private final ProjetoService service;

    public ProjetoController(ProjetoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Projeto> listar() {
        return service.listarTodos();
    }

    @PostMapping
    public ResponseEntity<Projeto> criar(@RequestBody Projeto projeto) {
        return ResponseEntity.ok(service.salvar(projeto));
    }

}
