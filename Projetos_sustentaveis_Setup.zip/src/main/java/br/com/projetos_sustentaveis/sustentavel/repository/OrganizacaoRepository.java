package br.com.projetos_sustentaveis.sustentavel.repository;

import br.com.projetos_sustentaveis.sustentavel.entity.Organizacao;
import org.springframework.data.jpa.repository.JpaRepository;

public class OrganizacaoRepository extends JpaRepository<Organizacao, Long> {
}
