package br.com.projetos_sustentaveis.sustentavel.service;

import br.com.projetos_sustentaveis.sustentavel.entity.Organizacao;
import br.com.projetos_sustentaveis.sustentavel.repository.OrganizacaoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizacaoService {

    private final OrganizacaoRepository repository;

    public OrganizacaoService(OrganizacaoRepository repository) {
        this.repository = repository;
    }

    public List<Organizacao> listarTodas() {
        return repository.findAll();
    }

    public Organizacao salvar(Organizacao organizacao) {
        return repository.save(organizacao);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }

}
