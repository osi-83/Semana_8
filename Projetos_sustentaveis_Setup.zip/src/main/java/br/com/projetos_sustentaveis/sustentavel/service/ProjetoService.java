package br.com.projetos_sustentaveis.sustentavel.service;

import br.com.projetos_sustentaveis.sustentavel.entity.Projeto;
import br.com.projetos_sustentaveis.sustentavel.repository.ProjetoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjetoService {

    private final ProjetoRepository repository;

    public ProjetoService(ProjetoRepository repository) {
        this.repository = repository;
    }

    public List<Projeto> listarTodos() {
        return repository.findAll();
    }

    public Projeto salvar(Projeto projeto) {
        return repository.save(projeto);
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}
