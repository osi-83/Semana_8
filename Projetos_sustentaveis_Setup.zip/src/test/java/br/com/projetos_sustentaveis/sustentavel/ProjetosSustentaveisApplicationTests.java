package br.com.projetos_sustentaveis.sustentavel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetosSustentaveisApplicationTests {

    @Test
    void contextLoads() {
    }

}
